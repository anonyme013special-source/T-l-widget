package com.amaid.telewidget

/**
 * Codes NEC 32 bits (hex MSB-first).
 * LG : codes standards (adresse 0x04), fiables.
 * TCL : codes de départ (NEC 0x40BF...) NON vérifiés sur ta télé.
 *       Si un bouton TCL ne réagit pas, change juste la valeur ici.
 */
object IrCodes {
    val LG = mapOf(
        "power" to 0x20DF10EFL, "volup" to 0x20DF40BFL, "voldown" to 0x20DFC03FL,
        "mute" to 0x20DF906FL, "chup" to 0x20DF00FFL, "chdown" to 0x20DF807FL
    )
    val TCL = mapOf(
        "power" to 0x40BF12EDL, "volup" to 0x40BF1AE5L, "voldown" to 0x40BF1EE1L,
        "mute" to 0x40BF0DF2L, "chup" to 0x40BF1BE4L, "chdown" to 0x40BF1FE0L
    )

    fun necPattern(code: Long): IntArray {
        val p = ArrayList<Int>()
        p.add(9000); p.add(4500)
        for (i in 31 downTo 0) {
            p.add(560)
            p.add(if (((code shr i) and 1L) == 1L) 1690 else 560)
        }
        p.add(560)
        return p.toIntArray()
    }
}
