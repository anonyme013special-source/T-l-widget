package com.amaid.telewidget

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val t = TextView(this)
        t.text = "TeleWidget installé.\n\nAppui long sur l'écran d'accueil → Widgets → TeleWidget."
        t.textSize = 18f
        t.setPadding(48, 120, 48, 48)
        setContentView(t)
    }
}
