package com.amaid.telewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.hardware.ConsumerIrManager
import android.net.Uri
import android.widget.RemoteViews
import android.widget.Toast

class TeleWidgetProvider : AppWidgetProvider() {

    private val keys = listOf("power", "volup", "voldown", "mute", "chup", "chdown")

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val views = RemoteViews(context.packageName, R.layout.widget_tele)
        for (tv in listOf("tcl", "lg")) {
            for (k in keys) {
                val viewId = context.resources.getIdentifier("${tv}_$k", "id", context.packageName)
                val intent = Intent(context, TeleWidgetProvider::class.java).apply {
                    action = ACTION_SEND
                    data = Uri.parse("tele://$tv/$k")
                    putExtra("tv", tv)
                    putExtra("key", k)
                }
                val pi = PendingIntent.getBroadcast(
                    context, "$tv$k".hashCode(), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(viewId, pi)
            }
        }
        for (id in ids) mgr.updateAppWidget(id, views)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION_SEND) return
        val ir = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        if (ir == null || !ir.hasIrEmitter()) {
            Toast.makeText(context, "Pas d'émetteur infrarouge", Toast.LENGTH_SHORT).show()
            return
        }
        val codes = if (intent.getStringExtra("tv") == "lg") IrCodes.LG else IrCodes.TCL
        val code = codes[intent.getStringExtra("key")] ?: return
        ir.transmit(38000, IrCodes.necPattern(code))
    }

    companion object { const val ACTION_SEND = "com.amaid.telewidget.SEND" }
}
