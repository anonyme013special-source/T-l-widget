package com.amaid.telewidget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.SizeF
import android.widget.RemoteViews

object Ui {

    class Theme(
        val panel: Int, val key: Int, val pow: Int, val ok: Int,
        val tabOn: Int, val tabOff: Int, val rocker: Int, val rk: Int,
        val icon: Int, val tabOnText: Int, val tabOffText: Int
    )

    val themes = listOf(
        // 0 : Cristal (verre clair)
        Theme(
            R.drawable.bg_panel_c, R.drawable.bg_key_c, R.drawable.bg_pow_c, R.drawable.bg_ok_c,
            R.drawable.bg_tab_on_c, R.drawable.bg_tab_off_c, R.drawable.bg_rocker_c, R.drawable.bg_rk_c,
            0xFFFFFFFF.toInt(), 0xFF0B1020.toInt(), 0xCCFFFFFF.toInt()
        ),
        // 1 : Néon (verre sombre, cyan)
        Theme(
            R.drawable.bg_panel_n, R.drawable.bg_key_n, R.drawable.bg_pow_n, R.drawable.bg_ok_n,
            R.drawable.bg_tab_on_n, R.drawable.bg_tab_off_n, R.drawable.bg_rocker_n, R.drawable.bg_rk_n,
            0xFFE6FBFF.toInt(), 0xFF00131A.toInt(), 0xCCE6FBFF.toInt()
        ),
        // 2 : Lave (verre sombre, orange)
        Theme(
            R.drawable.bg_panel_l, R.drawable.bg_key_l, R.drawable.bg_pow_l, R.drawable.bg_ok_l,
            R.drawable.bg_tab_on_l, R.drawable.bg_tab_off_l, R.drawable.bg_rocker_l, R.drawable.bg_rk_l,
            0xFFFFEBDD.toInt(), 0xFF2A0F05.toInt(), 0xCCFFEBDD.toInt()
        )
    )

    private val iconKeys = listOf(
        R.id.k_source to "source", R.id.k_mute to "mute",
        R.id.k_up to "up", R.id.k_down to "down", R.id.k_left to "left", R.id.k_right to "right",
        R.id.k_back to "back", R.id.k_home to "home", R.id.k_menu to "menu"
    )

    private val rockerKeys = listOf(
        R.id.k_volup to "volup", R.id.k_voldown to "voldown",
        R.id.k_chup to "chup", R.id.k_chdown to "chdown"
    )

    /** Widget responsive : petit (4x2) = barre compacte, grand (4x4) = télécommande complète. */
    fun build(ctx: Context): RemoteViews {
        val compact = make(ctx, R.layout.remote_compact, true)
        if (Build.VERSION.SDK_INT < 31) return compact
        val full = make(ctx, R.layout.remote_full, false)
        return RemoteViews(mapOf(SizeF(250f, 110f) to compact, SizeF(250f, 300f) to full))
    }

    private fun make(ctx: Context, layout: Int, compact: Boolean): RemoteViews {
        val rv = RemoteViews(ctx.packageName, layout)
        val t = themes[Prefs.theme(ctx).coerceIn(0, themes.size - 1)]
        val tclOn = Prefs.tv(ctx) == "tcl"

        rv.setInt(R.id.panel, "setBackgroundResource", t.panel)

        // Onglets TCL / LG
        rv.setInt(R.id.tab_tcl, "setBackgroundResource", if (tclOn) t.tabOn else t.tabOff)
        rv.setTextColor(R.id.tab_tcl, if (tclOn) t.tabOnText else t.tabOffText)
        rv.setInt(R.id.tab_lg, "setBackgroundResource", if (tclOn) t.tabOff else t.tabOn)
        rv.setTextColor(R.id.tab_lg, if (tclOn) t.tabOffText else t.tabOnText)
        rv.setOnClickPendingIntent(R.id.tab_tcl, pi(ctx, TeleWidgetProvider.ACTION_TV, "tcl"))
        rv.setOnClickPendingIntent(R.id.tab_lg, pi(ctx, TeleWidgetProvider.ACTION_TV, "lg"))

        // Bouton thème
        rv.setInt(R.id.btn_theme, "setBackgroundResource", t.key)
        rv.setInt(R.id.btn_theme, "setColorFilter", t.icon)
        rv.setOnClickPendingIntent(R.id.btn_theme, pi(ctx, TeleWidgetProvider.ACTION_THEME, "next"))

        // Touches
        key(ctx, rv, R.id.k_power, "power", t.pow, t.icon)
        for ((id, k) in iconKeys) key(ctx, rv, id, k, t.key, t.icon)
        for ((id, k) in rockerKeys) key(ctx, rv, id, k, if (compact) t.key else t.rk, t.icon)

        rv.setInt(R.id.k_ok, "setBackgroundResource", t.ok)
        rv.setTextColor(R.id.k_ok, t.icon)
        rv.setOnClickPendingIntent(R.id.k_ok, keyPi(ctx, "ok"))

        rv.setInt(R.id.k_netflix, "setBackgroundResource", t.key)
        rv.setOnClickPendingIntent(R.id.k_netflix, keyPi(ctx, "netflix"))

        // Bascules volume / chaînes
        rv.setInt(R.id.rocker_vol, "setBackgroundResource", t.rocker)
        rv.setInt(R.id.rocker_ch, "setBackgroundResource", t.rocker)
        rv.setTextColor(R.id.lbl_vol, t.icon)
        rv.setTextColor(R.id.lbl_ch, t.icon)
        return rv
    }

    private fun key(ctx: Context, rv: RemoteViews, id: Int, k: String, bg: Int, tint: Int) {
        rv.setInt(id, "setBackgroundResource", bg)
        rv.setInt(id, "setColorFilter", tint)
        rv.setOnClickPendingIntent(id, keyPi(ctx, k))
    }

    private fun keyPi(ctx: Context, k: String) = pi(ctx, TeleWidgetProvider.ACTION_KEY, k)

    private fun pi(ctx: Context, action: String, arg: String): PendingIntent {
        val i = Intent(ctx, TeleWidgetProvider::class.java)
        i.action = action
        i.data = Uri.parse("tele://$action/$arg")
        i.putExtra("arg", arg)
        return PendingIntent.getBroadcast(
            ctx, (action + arg).hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
