package com.amaid.telewidget

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

abstract class BaseTile(private val tvKey: String, private val title: String) : TileService() {

    override fun onStartListening() {
        val tile = qsTile ?: return
        tile.label = title
        tile.state = Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = "Marche / Arrêt"
        tile.updateTile()
    }

    override fun onClick() {
        IrSender.send(this, tvKey, "power")
    }
}

class TclTile : BaseTile("tcl", "TV TCL")

class LgTile : BaseTile("lg", "TV LG")
