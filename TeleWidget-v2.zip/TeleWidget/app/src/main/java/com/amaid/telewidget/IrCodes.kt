package com.amaid.telewidget

/**
 * LG  : NEC 32 bits (adresse 0x04), codes standards.
 * TCL : protocole 24 bits (famille "Nikai" : entête 4000/4000 µs, 1 = 2000 µs, 0 = 1000 µs),
 *       codes relevés sur des TCL Google/Android TV (55P715, 55T8B).
 *       Si ta TCL ne réagit pas : réglage "variante inversée" dans l'app.
 */
object IrCodes {
    val LG: Map<String, Long> = mapOf(
        "power" to 0x20DF10EFL, "volup" to 0x20DF40BFL, "voldown" to 0x20DFC03FL, "mute" to 0x20DF906FL,
        "chup" to 0x20DF00FFL, "chdown" to 0x20DF807FL,
        "up" to 0x20DF02FDL, "down" to 0x20DF827DL, "left" to 0x20DFE01FL, "right" to 0x20DF609FL,
        "ok" to 0x20DF22DDL, "back" to 0x20DF14EBL, "home" to 0x20DF3EC1L, "menu" to 0x20DFC23DL,
        "source" to 0x20DFD02FL, "netflix" to 0x20DF6A95L
    )

    val TCL: Map<String, Long> = mapOf(
        "power" to 0x0D5F2AL, "volup" to 0x0D0F2FL, "voldown" to 0x0D1F2EL, "mute" to 0x0C0F3FL,
        "chup" to 0x0D2F2DL, "chdown" to 0x0D3F2CL,
        "up" to 0x0A6F59L, "down" to 0x0A7F58L, "left" to 0x0A9F56L, "right" to 0x0A8F57L,
        "ok" to 0x00BFF4L, "back" to 0x0D8F27L, "home" to 0x0F7F08L, "menu" to 0x013FECL,
        "source" to 0x05CFA3L, "netflix" to 0x010FEFL
    )

    fun pattern(tv: String, key: String, tclInverted: Boolean): IntArray? {
        return if (tv == "lg") {
            LG[key]?.let { nec(it) }
        } else {
            TCL[key]?.let { nikai(if (tclInverted) it xor 0xFFFFFFL else it) }
        }
    }

    private fun nec(code: Long): IntArray {
        val p = ArrayList<Int>()
        p.add(9000); p.add(4500)
        for (i in 31 downTo 0) {
            p.add(560)
            p.add(if (((code shr i) and 1L) == 1L) 1690 else 560)
        }
        p.add(560)
        return p.toIntArray()
    }

    private fun nikai(code: Long): IntArray {
        val p = ArrayList<Int>()
        p.add(4000); p.add(4000)
        for (i in 23 downTo 0) {
            p.add(500)
            p.add(if (((code shr i) and 1L) == 1L) 2000 else 1000)
        }
        p.add(500)
        return p.toIntArray()
    }
}
