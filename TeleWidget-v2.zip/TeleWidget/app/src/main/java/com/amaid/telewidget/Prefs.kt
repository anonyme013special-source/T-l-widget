package com.amaid.telewidget

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("tele", Context.MODE_PRIVATE)

    fun tv(c: Context): String = sp(c).getString("tv", "tcl") ?: "tcl"
    fun setTv(c: Context, v: String) = sp(c).edit().putString("tv", v).apply()

    fun theme(c: Context): Int = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun tclInverted(c: Context): Boolean = sp(c).getBoolean("tclInv", false)
    fun setTclInverted(c: Context, v: Boolean) = sp(c).edit().putBoolean("tclInv", v).apply()
}
