package com.amaid.telewidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun px(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(0, px(6), 0, px(6))
        return tv
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = px(18).toFloat()
        bg.setColor(Color.parseColor("#33FFFFFF"))
        bg.setStroke(px(1), Color.parseColor("#66FFFFFF"))
        b.background = bg
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(56))
        lp.topMargin = px(10)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(22), px(56), px(22), px(32))

        val soft = Color.parseColor("#99FFFFFF")
        root.addView(label("TeleWidget", 32f, Color.WHITE, true))
        root.addView(label("Ta télécommande TCL + LG, en verre liquide.", 15f, soft, false))

        val ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        val hasIr = ir != null && ir.hasIrEmitter()
        root.addView(
            label(
                if (hasIr) "Émetteur infrarouge : détecté ✅" else "Émetteur infrarouge : introuvable ❌",
                15f, if (hasIr) Color.parseColor("#7DF9A6") else Color.parseColor("#FF8A8A"), true
            )
        )

        root.addView(button("➕  Ajouter le widget à l'écran d'accueil") {
            val mgr = AppWidgetManager.getInstance(this)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(this, TeleWidgetProvider::class.java), null, null)
            } else {
                toast("Appui long sur l'accueil, puis Widgets, puis TeleWidget")
            }
        })

        root.addView(label("Tests rapides", 18f, Color.WHITE, true))
        root.addView(button("⏻  Tester la LG (marche / arrêt)") { IrSender.send(this, "lg", "power") })
        root.addView(button("⏻  Tester la TCL (marche / arrêt)") { IrSender.send(this, "tcl", "power") })

        val sw = Switch(this)
        sw.text = "TCL : variante inversée (à essayer si la TCL ne réagit pas)"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Prefs.tclInverted(this)
        sw.setPadding(0, px(16), 0, px(8))
        sw.setOnCheckedChangeListener { _, checked ->
            Prefs.setTclInverted(this, checked)
            toast(if (checked) "Variante inversée activée, retente le test TCL" else "Variante normale activée")
        }
        root.addView(sw)

        root.addView(label("Astuce", 18f, Color.WHITE, true))
        root.addView(
            label(
                "Ajoute aussi les tuiles « TV LG » et « TV TCL » dans tes réglages rapides pour allumer ou éteindre une télé sans ouvrir quoi que ce soit.\n\n" +
                    "Sur le widget : touche TCL / LG pour changer de télé, touche palette pour changer de thème. Agrandis-le pour voir la télécommande complète.",
                14f, soft, false
            )
        )

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0B1020"))
        scroll.addView(root)
        setContentView(scroll)
    }
}
