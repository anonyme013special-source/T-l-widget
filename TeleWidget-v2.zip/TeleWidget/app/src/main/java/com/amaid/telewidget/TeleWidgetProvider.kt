package com.amaid.telewidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent

class TeleWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val rv = Ui.build(context)
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, rv)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val arg = intent.getStringExtra("arg") ?: ""
        when (intent.action) {
            ACTION_KEY -> {
                IrSender.send(context, Prefs.tv(context), arg)
            }
            ACTION_TV -> {
                IrSender.haptic(context)
                Prefs.setTv(context, if (arg == "lg") "lg" else "tcl")
                refresh(context)
            }
            ACTION_THEME -> {
                IrSender.haptic(context)
                Prefs.setTheme(context, (Prefs.theme(context) + 1) % Ui.themes.size)
                refresh(context)
            }
        }
    }

    companion object {
        const val ACTION_KEY = "com.amaid.telewidget.KEY"
        const val ACTION_TV = "com.amaid.telewidget.TV"
        const val ACTION_THEME = "com.amaid.telewidget.THEME"

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, TeleWidgetProvider::class.java))
            if (ids.isNotEmpty()) mgr.updateAppWidget(ids, Ui.build(ctx))
        }
    }
}
