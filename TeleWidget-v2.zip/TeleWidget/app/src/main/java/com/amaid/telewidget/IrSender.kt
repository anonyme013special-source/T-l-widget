package com.amaid.telewidget

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast

object IrSender {

    fun send(ctx: Context, tv: String, key: String): Boolean {
        val ir = ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        if (ir == null || !ir.hasIrEmitter()) {
            Toast.makeText(ctx, "Pas d'émetteur infrarouge sur ce téléphone", Toast.LENGTH_SHORT).show()
            return false
        }
        val pattern = IrCodes.pattern(tv, key, Prefs.tclInverted(ctx)) ?: return false
        haptic(ctx)
        ir.transmit(38000, pattern)
        return true
    }

    @Suppress("DEPRECATION")
    fun haptic(ctx: Context) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 29) {
                v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (e: Throwable) {
        }
    }
}
