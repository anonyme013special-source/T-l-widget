package com.amaid.glasswidgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class RemoteWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, build(ctx)) }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        val prefs = ctx.getSharedPreferences("remote", Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_TAB -> { prefs.edit().putString("tv", intent.getStringExtra("tv")).apply(); refresh(ctx) }
            ACTION_THEME -> { prefs.edit().putInt("theme", (prefs.getInt("theme", 0) + 1) % 3).apply(); refresh(ctx) }
            ACTION_KEY -> IrSender.send(ctx, prefs.getString("tv", "LG")!!, intent.getStringExtra("key") ?: return)
        }
    }

    private fun refresh(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, RemoteWidget::class.java))
        ids.forEach { mgr.updateAppWidget(it, build(ctx)) }
    }

    private fun build(ctx: Context): RemoteViews {
        val prefs = ctx.getSharedPreferences("remote", Context.MODE_PRIVATE)
        val tv = prefs.getString("tv", "LG")!!
        val theme = prefs.getInt("theme", 0)
        val v = RemoteViews(ctx.packageName, R.layout.remote_widget)

        val on = Color.WHITE
        val off = Color.parseColor("#B3FFFFFF")
        v.setInt(R.id.tab_tcl, "setBackgroundResource", if (tv == "TCL") R.drawable.tab_on else R.drawable.tab_off)
        v.setInt(R.id.tab_lg, "setBackgroundResource", if (tv == "LG") R.drawable.tab_on else R.drawable.tab_off)
        v.setTextColor(R.id.tab_tcl, if (tv == "TCL") on else off)
        v.setTextColor(R.id.tab_lg, if (tv == "LG") on else off)
        v.setInt(R.id.btn_power, "setBackgroundResource",
            intArrayOf(R.drawable.tile_red, R.drawable.tile_blue, R.drawable.tile_green)[theme])

        v.setOnClickPendingIntent(R.id.tab_tcl, pi(ctx, ACTION_TAB, null, "TCL"))
        v.setOnClickPendingIntent(R.id.tab_lg, pi(ctx, ACTION_TAB, null, "LG"))
        v.setOnClickPendingIntent(R.id.btn_theme, pi(ctx, ACTION_THEME, null))
        mapOf(
            R.id.btn_power to "power", R.id.btn_vol_down to "vol_down", R.id.btn_vol_up to "vol_up",
            R.id.btn_mute to "mute", R.id.btn_ch_down to "ch_down", R.id.btn_ch_up to "ch_up"
        ).forEach { (id, key) -> v.setOnClickPendingIntent(id, pi(ctx, ACTION_KEY, key)) }
        return v
    }

    private fun pi(ctx: Context, action: String, key: String?, tv: String? = null): PendingIntent {
        val i = Intent(ctx, RemoteWidget::class.java).setAction(action)
        key?.let { i.putExtra("key", it) }
        tv?.let { i.putExtra("tv", it) }
        return PendingIntent.getBroadcast(
            ctx, "$action$key$tv".hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object {
        const val ACTION_KEY = "com.amaid.glasswidgets.KEY"
        const val ACTION_TAB = "com.amaid.glasswidgets.TAB"
        const val ACTION_THEME = "com.amaid.glasswidgets.THEME"
    }
}
