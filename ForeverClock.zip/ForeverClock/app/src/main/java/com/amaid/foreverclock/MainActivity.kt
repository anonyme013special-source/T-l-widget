package com.amaid.foreverclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun px(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(24), px(64), px(24), px(24))

        val title = TextView(this)
        title.text = "forever clock"
        title.textSize = 34f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.parseColor("#111111"))
        root.addView(title)

        val sub = TextView(this)
        sub.text = "Horloge analogique + heure numérique, sur fond « forever »."
        sub.textSize = 15f
        sub.setTextColor(Color.parseColor("#777777"))
        sub.setPadding(0, px(8), 0, px(24))
        root.addView(sub)

        val b = Button(this)
        b.text = "Ajouter le widget à l'écran d'accueil"
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = px(18).toFloat()
        bg.setColor(Color.parseColor("#111111"))
        b.background = bg
        b.setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
            } else {
                Toast.makeText(this, "Appui long sur l'accueil, puis Widgets, puis Forever Clock", Toast.LENGTH_LONG).show()
            }
        }
        b.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(56))
        root.addView(b)

        setContentView(root)
    }
}
